# ESP32 Synth - Menu Structure & Controls

## Mode Navigation Flow

```
┌─────────────┐
│   MODE BTN  │ (Press to cycle)
└──────┬──────┘
       │
       ▼
┌──────────────────────────────────────────────┐
│  MODE 1: LAUNCHPAD                           │
│  ┌────────────────────────────────────────┐  │
│  │ • Play notes live with 4x4 pad grid   │  │
│  │ • Waveform visualizer on left         │  │
│  │ • Octave control with BTN_OCTAVE      │  │
│  └────────────────────────────────────────┘  │
└──────────────────────────────────────────────┘
       │
       ▼ (Press MODE)
┌──────────────────────────────────────────────┐
│  MODE 2: SEQUENCER                           │
│  ┌────────────────────────────────────────┐  │
│  │ • 16-step sequencer                    │  │
│  │ • 4 tracks visible                     │  │
│  │ • Track switching with BTN_OCTAVE      │  │
│  │ • Play/pause with sequencer            │  │
│  └────────────────────────────────────────┘  │
└──────────────────────────────────────────────┘
       │
       ▼ (Press MODE)
┌──────────────────────────────────────────────┐
│  MODE 3: SETTINGS                            │
│  ┌────────────────────────────────────────┐  │
│  │ Scrollable Menu (9 items):             │  │
│  │ 1. Instrument                          │  │
│  │ 2. BPM                                 │  │
│  │ 3. Play/Pause                          │  │
│  │ 4. Clear Track                         │  │
│  │ 5. Volume                              │  │
│  │ 6. Brightness                          │  │
│  │ 7. Swing          ← NEW                │  │
│  │ 8. Gate           ← NEW                │  │
│  │ 9. Filter         ← NEW                │  │
│  └────────────────────────────────────────┘  │
└──────────────────────────────────────────────┘
       │
       ▼ (Press MODE)
┌──────────────────────────────────────────────┐
│  MODE 4: NOTE EDITOR                         │
│  ┌────────────────────────────────────────┐  │
│  │ • Coming Soon...                       │  │
│  │ • Placeholder UI implemented           │  │
│  │ • Future: Edit individual step notes  │  │
│  └────────────────────────────────────────┘  │
└──────────────────────────────────────────────┘
       │
       └─────► (Press MODE - cycles back to LAUNCHPAD)
```

---

## Settings Menu Controls

```
┌─────────────────────────────────────────────────┐
│              SETTINGS MENU                      │
│                                                 │
│  Navigation:                                    │
│  ┌─────────┐                                    │
│  │  PAD 0  │ ──► Move cursor UP                 │
│  └─────────┘                                    │
│  ┌─────────┐                                    │
│  │  PAD 1  │ ──► Move cursor DOWN               │
│  └─────────┘                                    │
│                                                 │
│  Value Control:                                 │
│  ┌─────────┐                                    │
│  │  PAD 2  │ ──► SELECT / Cycle preset values   │
│  └─────────┘                                    │
│  ┌─────────┐                                    │
│  │  PAD 3  │ ──► DECREASE value                 │
│  └─────────┘                                    │
│  ┌─────────┐                                    │
│  │  PAD 4  │ ──► INCREASE value                 │
│  └─────────┘                                    │
└─────────────────────────────────────────────────┘
```

---

## New Settings Details

### 🎵 SWING (Menu Item 7)

```
┌──────────────────────────────────────┐
│ > Swing                         50%  │
└──────────────────────────────────────┘

Controls: 
  PAD 2: 0% → 25% → 50% → 75% → 100% → 0%
  PAD 3: Current - 5%
  PAD 4: Current + 5%

Effect:
  0%   ┌─┬─┬─┬─┐  Straight timing
       │ │ │ │ │
       
  50%  ┌──┬┬──┬┐  Swung timing
       │  ││  ││  (even steps longer)
       
  100% ┌───┬───┐  Maximum swing
       │   │   │
```

### 🎹 GATE (Menu Item 8)

```
┌──────────────────────────────────────┐
│ > Gate                          80%  │
└──────────────────────────────────────┘

Controls:
  PAD 2: 25% → 50% → 75% → 100% → 25%
  PAD 3: Current - 5%
  PAD 4: Current + 5%

Effect:
  25%  ▂  ▂  ▂  ▂   Staccato (short)
  
  50%  ▄▄ ▄▄ ▄▄ ▄▄  Medium
  
  80%  ▆▆▆▆▆▆▆▆▆▆  Default (slight gap)
  
  100% ████████████  Legato (full)
```

### 🔊 FILTER (Menu Item 9)

```
┌──────────────────────────────────────┐
│ > Filter                        50%  │
└──────────────────────────────────────┘

Controls:
  PAD 2: 25% → 50% → 75% → 100% → 25%
  PAD 3: Current - 5%
  PAD 4: Current + 5%

Effect:
  25%  ▁▁▁▁▁▁▁▁▁▁  Dark, muffled
  
  50%  ▃▃▃▃▃▃▃▃▃▃  Balanced (default)
  
  75%  ▅▅▅▅▅▅▅▅▅▅  Bright
  
  100% ▇▇▇▇▇▇▇▇▇▇  Full brightness
```

---

## Audio Signal Flow (Updated)

```
┌──────────────┐
│ Voice Engine │ (8 voices, polyphony)
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ Voice Mixing │ (soft scaling)
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ Master Vol   │ (0-100%)
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ Low-Pass     │ ← FILTER CUTOFF (NEW)
│ Filter       │   (0-100% adjustable)
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ DC Blocker   │ ← FIXED: Both channels
│ (Stereo)     │   process independently
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ Clipping     │ (±1.0)
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ I2S Output   │ (PCM5102A DAC)
│ (Stereo)     │
└──────────────┘
```

---

## Sequencer Timing (Updated)

```
Without Swing (0%):
Step:  0   1   2   3   4   5   6   7
Time: ┌─┬─┬─┬─┬─┬─┬─┬─┐
      │ │ │ │ │ │ │ │ │
      └─┴─┴─┴─┴─┴─┴─┴─┘
      Equal spacing

With Swing (50%):
Step:  0   1   2   3   4   5   6   7
Time: ┌──┬┬──┬┬──┬┬──┬┐
      │  ││  ││  ││  ││
      └──┴┴──┴┴──┴┴──┴┘
      Even steps longer, odd steps shorter

Gate Length Effect:
100%: ████████████████  Full length
 80%: ███ ███ ███ ███  Default (slight gap)
 50%: ██  ██  ██  ██   Medium
 25%: █   █   █   █    Staccato
```

---

## Bug Fixes Visualization

### Before: DC Blocker Issue
```
Input (Mono) ──┬──► DC Block ──► Left  ─┐
               │                        ├─► Output
               └──► [COPY]    ──► Right ┘
                    ❌ Not filtered!
```

### After: DC Blocker Fixed
```
Input (Mono) ──┬──► DC Block ──► Left  ─┐
               │                        ├─► Output
               └──► DC Block ──► Right ┘
                    ✅ Both filtered!
```

### Before: Voice Stealing
```
All 8 voices active
New note arrives
findFreeVoice() returns -1  ❌
Note is dropped!
```

### After: Voice Stealing
```
All 8 voices active
New note arrives
findFreeVoice() finds lowest envelope  ✅
Steals that voice
New note plays!
```

---

## Display Layout Examples

### Settings Menu (Showing New Items)
```
┌────────────────────────────┐
│ Settings                   │
├────────────────────────────┤
│   Brightness          100% │
│ > Swing                50% │
│   Gate                 80% │
│   Filter               50% │
│                          v │
└────────────────────────────┘
```

### Note Editor (Placeholder)
```
┌────────────────────────────┐
│ Note Editor                │
├────────────────────────────┤
│                            │
│   Coming Soon...           │
│   Edit individual          │
│   step notes here          │
│                            │
└────────────────────────────┘
```

---

*Visual reference for ESP32 Synth v2.0*
*Updated: 2026-01-28*
