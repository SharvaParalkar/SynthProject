#include "AudioEngine.h"
#include <math.h>
#include <string.h>

// ============================================================================
// CONSTANTS
// ============================================================================

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#ifndef M_2PI
#define M_2PI (2.0 * M_PI)
#endif

// Sample rate for calculations
static constexpr float SAMPLE_RATE_F = (float)AUDIO_SAMPLE_RATE;
static constexpr double SAMPLE_RATE_D = (double)AUDIO_SAMPLE_RATE;

// ============================================================================
// ENVELOPE IMPLEMENTATION
// ============================================================================

void Envelope::trigger(const ADSRParams& params) {
    // Calculate rates (samples to reach target)
    // Using exponential curves for more natural sound
    float sampleRate = SAMPLE_RATE_F;
    
    // Attack: time to go from 0 to 1
    if (params.attack > 0.001f) {
        attackRate = 1.0f / (params.attack * sampleRate);
    } else {
        attackRate = 1.0f; // Instant attack
    }
    
    // Decay: time to go from 1 to sustain level
    if (params.decay > 0.001f) {
        // Exponential decay coefficient
        decayRate = expf(-1.0f / (params.decay * sampleRate));
    } else {
        decayRate = 0.0f;
    }
    
    sustainLevel = params.sustain;
    
    // Release: time to go from sustain to 0
    if (params.release > 0.001f) {
        releaseRate = expf(-1.0f / (params.release * sampleRate));
    } else {
        releaseRate = 0.0f;
    }
    
    state = ENV_ATTACK;
    // Don't reset level - allows retriggering without click
    if (level < 0.001f) level = 0.0f;
}

void Envelope::release() {
    if (state != ENV_IDLE) {
        state = ENV_RELEASE;
    }
}

void Envelope::reset() {
    state = ENV_IDLE;
    level = 0.0f;
}

float Envelope::process() {
    switch (state) {
        case ENV_ATTACK:
            level += attackRate;
            if (level >= 1.0f) {
                level = 1.0f;
                state = ENV_DECAY;
            }
            break;
            
        case ENV_DECAY:
            // Exponential decay towards sustain level
            level = sustainLevel + (level - sustainLevel) * decayRate;
            if (level <= sustainLevel + 0.001f) {
                level = sustainLevel;
                state = ENV_SUSTAIN;
            }
            break;
            
        case ENV_SUSTAIN:
            // Hold at sustain level
            level = sustainLevel;
            break;
            
        case ENV_RELEASE:
            // Exponential release towards zero
            level *= releaseRate;
            if (level < 0.0001f) {
                level = 0.0f;
                state = ENV_IDLE;
            }
            break;
            
        case ENV_IDLE:
        default:
            level = 0.0f;
            break;
    }
    
    return level;
}

// ============================================================================
// OSCILLATOR IMPLEMENTATION
// ============================================================================

void Oscillator::setFrequency(float freq) {
    frequency = freq;
    // Phase increment per sample (normalized 0-1)
    phaseIncrement = (double)freq / SAMPLE_RATE_D;
}

// ============================================================================
// VOICE IMPLEMENTATION
// ============================================================================

void Voice::noteOn(int midiNote, Instrument inst, float vel) {
    note = midiNote;
    instrument = inst;
    velocity = vel;
    active = true;
    startTime = millis();
    
    // Calculate base frequency
    float freq = 440.0f * powf(2.0f, (midiNote - 69) / 12.0f);
    
    // Set up oscillators
    osc.setFrequency(freq);
    osc.reset();
    
    // Sub-oscillator (one octave down)
    subOsc.setFrequency(freq * 0.5f);
    subOsc.reset();
    
    // Detuned oscillators for chorus/pad effects
    detunedOsc[0].setFrequency(freq * 1.003f);  // +5 cents
    detunedOsc[0].reset();
    detunedOsc[1].setFrequency(freq * 0.997f);  // -5 cents
    detunedOsc[1].reset();
    
    // Reset filter state
    filterState = 0.0f;
}

void Voice::noteOff() {
    ampEnv.release();
}

void Voice::reset() {
    active = false;
    note = -1;
    ampEnv.reset();
    osc.reset();
    subOsc.reset();
    detunedOsc[0].reset();
    detunedOsc[1].reset();
    filterState = 0.0f;
}

// ============================================================================
// AUDIO ENGINE IMPLEMENTATION
// ============================================================================

AudioEngine::AudioEngine() {
    sineTable = nullptr;
    sawTable = nullptr;
    squareTable = nullptr;
    triangleTable = nullptr;
    voiceMutex = nullptr;
    
    memset(visualizerBuffer, 0, sizeof(visualizerBuffer));
}

AudioEngine::~AudioEngine() {
    stop();
    destroyWavetables();
    if (voiceMutex) {
        vSemaphoreDelete(voiceMutex);
    }
}

void AudioEngine::init() {
    Serial.println("[AudioEngine] Initializing...");
    
    // Create voice mutex for thread safety
    voiceMutex = xSemaphoreCreateMutex();
    
    // Generate wavetables
    generateWavetables();
    
    // Initialize all voices
    for (int i = 0; i < MAX_POLYPHONY; i++) {
        voices[i].reset();
    }
    
    Serial.println("[AudioEngine] Initialized successfully");
}

void AudioEngine::generateWavetables() {
    Serial.println("[AudioEngine] Generating wavetables...");
    
    // Allocate wavetables (using malloc for PSRAM if available)
    sineTable = (float*)malloc(WAVETABLE_SIZE * sizeof(float));
    sawTable = (float*)malloc(WAVETABLE_SIZE * sizeof(float));
    squareTable = (float*)malloc(WAVETABLE_SIZE * sizeof(float));
    triangleTable = (float*)malloc(WAVETABLE_SIZE * sizeof(float));
    
    if (!sineTable || !sawTable || !squareTable || !triangleTable) {
        Serial.println("[AudioEngine] ERROR: Failed to allocate wavetables!");
        return;
    }
    
    // Generate sine table
    for (int i = 0; i < WAVETABLE_SIZE; i++) {
        float phase = (float)i / (float)WAVETABLE_SIZE;
        sineTable[i] = sinf(phase * M_2PI);
    }
    
    // Generate band-limited saw using additive synthesis
    // Limit harmonics to avoid aliasing at high frequencies
    memset(sawTable, 0, WAVETABLE_SIZE * sizeof(float));
    int maxHarmonics = AUDIO_SAMPLE_RATE / 2 / 440;  // Based on A4
    if (maxHarmonics > 64) maxHarmonics = 64;
    
    for (int h = 1; h <= maxHarmonics; h++) {
        float amplitude = 2.0f / (M_PI * h);
        if (h % 2 == 0) amplitude = -amplitude;  // Alternate sign for saw
        
        for (int i = 0; i < WAVETABLE_SIZE; i++) {
            float phase = (float)i / (float)WAVETABLE_SIZE;
            sawTable[i] += amplitude * sinf(h * phase * M_2PI);
        }
    }
    
    // Normalize saw table
    float maxSaw = 0.0f;
    for (int i = 0; i < WAVETABLE_SIZE; i++) {
        if (fabsf(sawTable[i]) > maxSaw) maxSaw = fabsf(sawTable[i]);
    }
    if (maxSaw > 0.0f) {
        for (int i = 0; i < WAVETABLE_SIZE; i++) {
            sawTable[i] /= maxSaw;
        }
    }
    
    // Generate band-limited square using additive synthesis (odd harmonics only)
    memset(squareTable, 0, WAVETABLE_SIZE * sizeof(float));
    for (int h = 1; h <= maxHarmonics; h += 2) {  // Odd harmonics only
        float amplitude = 4.0f / (M_PI * h);
        
        for (int i = 0; i < WAVETABLE_SIZE; i++) {
            float phase = (float)i / (float)WAVETABLE_SIZE;
            squareTable[i] += amplitude * sinf(h * phase * M_2PI);
        }
    }
    
    // Normalize square table
    float maxSquare = 0.0f;
    for (int i = 0; i < WAVETABLE_SIZE; i++) {
        if (fabsf(squareTable[i]) > maxSquare) maxSquare = fabsf(squareTable[i]);
    }
    if (maxSquare > 0.0f) {
        for (int i = 0; i < WAVETABLE_SIZE; i++) {
            squareTable[i] /= maxSquare;
        }
    }
    
    // Generate triangle table (integrated square)
    memset(triangleTable, 0, WAVETABLE_SIZE * sizeof(float));
    for (int h = 1; h <= maxHarmonics; h += 2) {  // Odd harmonics only
        float amplitude = 8.0f / (M_PI * M_PI * h * h);
        if ((h / 2) % 2 == 1) amplitude = -amplitude;  // Alternate sign
        
        for (int i = 0; i < WAVETABLE_SIZE; i++) {
            float phase = (float)i / (float)WAVETABLE_SIZE;
            triangleTable[i] += amplitude * sinf(h * phase * M_2PI);
        }
    }
    
    // Normalize triangle table
    float maxTri = 0.0f;
    for (int i = 0; i < WAVETABLE_SIZE; i++) {
        if (fabsf(triangleTable[i]) > maxTri) maxTri = fabsf(triangleTable[i]);
    }
    if (maxTri > 0.0f) {
        for (int i = 0; i < WAVETABLE_SIZE; i++) {
            triangleTable[i] /= maxTri;
        }
    }
    
    Serial.printf("[AudioEngine] Wavetables generated (%d samples each)\n", WAVETABLE_SIZE);
}

void AudioEngine::destroyWavetables() {
    if (sineTable) { free(sineTable); sineTable = nullptr; }
    if (sawTable) { free(sawTable); sawTable = nullptr; }
    if (squareTable) { free(squareTable); squareTable = nullptr; }
    if (triangleTable) { free(triangleTable); triangleTable = nullptr; }
}

void AudioEngine::start() {
    audioTaskRunning = true;
    Serial.println("[AudioEngine] Started");
}

void AudioEngine::stop() {
    audioTaskRunning = false;
    Serial.println("[AudioEngine] Stopped");
}

// ============================================================================
// VOLUME AND FILTER CONTROL
// ============================================================================

void AudioEngine::setVolume(int vol) {
    vol = constrain(vol, 0, 100);
    masterVolume = (float)vol / 100.0f;
}

int AudioEngine::getVolume() {
    return (int)(masterVolume * 100.0f);
}

void AudioEngine::setFilterCutoff(float cutoff) {
    filterCutoff = constrain(cutoff, 0.0f, 1.0f);
}

float AudioEngine::getFilterCutoff() {
    return filterCutoff;
}

float AudioEngine::getVisualizerLevel() {
    return peakLevel;
}

// ============================================================================
// NOTE CONTROL
// ============================================================================

void AudioEngine::noteOn(int note, Instrument inst) {
    if (xSemaphoreTake(voiceMutex, pdMS_TO_TICKS(1)) == pdTRUE) {
        // Check if this note is already playing (prevent double-trigger)
        for (int i = 0; i < MAX_POLYPHONY; i++) {
            if (voices[i].active && voices[i].note == note && 
                voices[i].ampEnv.state != ENV_RELEASE) {
                xSemaphoreGive(voiceMutex);
                return;  // Note already playing
            }
        }
        
        // Find a free voice or steal one
        int voiceIndex = findFreeVoice();
        if (voiceIndex < 0) {
            voiceIndex = findVoiceToSteal();
        }
        
        if (voiceIndex >= 0) {
            Voice& v = voices[voiceIndex];
            
            // Get ADSR parameters for this instrument
            ADSRParams adsr = getADSRForInstrument(inst);
            
            // Trigger the note
            v.noteOn(note, inst, 1.0f);
            v.ampEnv.trigger(adsr);
        }
        
        xSemaphoreGive(voiceMutex);
    }
}

void AudioEngine::noteOff(int note) {
    if (xSemaphoreTake(voiceMutex, pdMS_TO_TICKS(1)) == pdTRUE) {
        for (int i = 0; i < MAX_POLYPHONY; i++) {
            if (voices[i].active && voices[i].note == note) {
                voices[i].noteOff();
            }
        }
        xSemaphoreGive(voiceMutex);
    }
}

void AudioEngine::killAll() {
    if (xSemaphoreTake(voiceMutex, pdMS_TO_TICKS(10)) == pdTRUE) {
        for (int i = 0; i < MAX_POLYPHONY; i++) {
            voices[i].reset();
        }
        
        // Reset master filter states
        masterLPState[0] = masterLPState[1] = 0.0f;
        dcBlockX[0] = dcBlockX[1] = 0.0f;
        dcBlockY[0] = dcBlockY[1] = 0.0f;
        
        xSemaphoreGive(voiceMutex);
    }
}

int AudioEngine::getActiveVoiceCount() {
    int count = 0;
    for (int i = 0; i < MAX_POLYPHONY; i++) {
        if (voices[i].active && voices[i].ampEnv.isActive()) {
            count++;
        }
    }
    return count;
}

// ============================================================================
// VOICE MANAGEMENT
// ============================================================================

int AudioEngine::findFreeVoice() {
    // First priority: completely inactive voices
    for (int i = 0; i < MAX_POLYPHONY; i++) {
        if (!voices[i].active || !voices[i].ampEnv.isActive()) {
            return i;
        }
    }
    return -1;
}

int AudioEngine::findVoiceToSteal() {
    // Steal the voice with the lowest envelope level
    int bestVoice = 0;
    float lowestLevel = voices[0].ampEnv.level;
    uint32_t oldestTime = voices[0].startTime;
    
    for (int i = 1; i < MAX_POLYPHONY; i++) {
        // Prefer voices in release state
        if (voices[i].ampEnv.state == ENV_RELEASE && 
            voices[bestVoice].ampEnv.state != ENV_RELEASE) {
            bestVoice = i;
            lowestLevel = voices[i].ampEnv.level;
            oldestTime = voices[i].startTime;
        }
        // Among same states, prefer lower level
        else if (voices[i].ampEnv.state == voices[bestVoice].ampEnv.state) {
            if (voices[i].ampEnv.level < lowestLevel) {
                bestVoice = i;
                lowestLevel = voices[i].ampEnv.level;
                oldestTime = voices[i].startTime;
            }
            // Same level? Prefer oldest
            else if (voices[i].ampEnv.level == lowestLevel && 
                     voices[i].startTime < oldestTime) {
                bestVoice = i;
                oldestTime = voices[i].startTime;
            }
        }
    }
    
    return bestVoice;
}

// ============================================================================
// ADSR PRESETS
// ============================================================================

ADSRParams AudioEngine::getADSRForInstrument(Instrument inst) {
    ADSRParams params;
    
    switch (inst) {
        case INST_SINE:
            params.attack = 0.01f;
            params.decay = 0.1f;
            params.sustain = 0.8f;
            params.release = 0.3f;
            break;
            
        case INST_SQUARE:
            params.attack = 0.005f;
            params.decay = 0.05f;
            params.sustain = 0.7f;
            params.release = 0.2f;
            break;
            
        case INST_SAW:
            params.attack = 0.003f;
            params.decay = 0.1f;
            params.sustain = 0.75f;
            params.release = 0.25f;
            break;
            
        case INST_TRIANGLE:
            params.attack = 0.02f;
            params.decay = 0.15f;
            params.sustain = 0.6f;
            params.release = 0.4f;
            break;
            
        case INST_PLUCK:
            params.attack = 0.001f;   // Very fast attack
            params.decay = 0.4f;      // Long decay
            params.sustain = 0.0f;    // No sustain (pluck fades)
            params.release = 0.1f;
            break;
            
        case INST_BASS:
            params.attack = 0.005f;
            params.decay = 0.15f;
            params.sustain = 0.6f;
            params.release = 0.15f;
            break;
            
        case INST_PAD:
            params.attack = 0.3f;     // Slow attack for pad
            params.decay = 0.5f;
            params.sustain = 0.7f;
            params.release = 0.8f;    // Long release
            break;
            
        case INST_LEAD:
            params.attack = 0.002f;
            params.decay = 0.08f;
            params.sustain = 0.85f;
            params.release = 0.15f;
            break;
            
        default:
            params.attack = 0.01f;
            params.decay = 0.1f;
            params.sustain = 0.7f;
            params.release = 0.3f;
            break;
    }
    
    return params;
}

// ============================================================================
// WAVETABLE READING
// ============================================================================

float AudioEngine::readWavetable(const float* table, double phase) {
    // Ensure phase is in [0, 1)
    phase = fmod(phase, 1.0);
    if (phase < 0.0) phase += 1.0;
    
    // Convert to table index
    double indexFloat = phase * WAVETABLE_SIZE;
    int index0 = (int)indexFloat & WAVETABLE_MASK;
    int index1 = (index0 + 1) & WAVETABLE_MASK;
    float frac = (float)(indexFloat - (int)indexFloat);
    
    // Linear interpolation for smooth output
    return table[index0] + frac * (table[index1] - table[index0]);
}

// ============================================================================
// FREQUENCY CONVERSION
// ============================================================================

float AudioEngine::midiToFrequency(int note) {
    return 440.0f * powf(2.0f, (note - 69) / 12.0f);
}

// ============================================================================
// VOICE RENDERING
// ============================================================================

float AudioEngine::generateVoiceSample(Voice& voice) {
    if (!voice.active) return 0.0f;
    
    float sample = 0.0f;
    
    // Select wavetable based on instrument
    switch (voice.instrument) {
        case INST_SINE:
            sample = readWavetable(sineTable, voice.osc.phase);
            break;
            
        case INST_SQUARE:
            sample = readWavetable(squareTable, voice.osc.phase);
            break;
            
        case INST_SAW:
            sample = readWavetable(sawTable, voice.osc.phase);
            break;
            
        case INST_TRIANGLE:
            sample = readWavetable(triangleTable, voice.osc.phase);
            break;
            
        case INST_PLUCK: {
            // Pluck: Start with harmonics, fade to sine
            float envLevel = voice.ampEnv.level;
            float saw = readWavetable(sawTable, voice.osc.phase);
            float sine = readWavetable(sineTable, voice.osc.phase);
            // As envelope decays, blend towards sine (darker tone)
            sample = envLevel * saw + (1.0f - envLevel) * sine;
            break;
        }
            
        case INST_BASS: {
            // Bass: Fundamental + sub-octave
            float main = readWavetable(sineTable, voice.osc.phase);
            float sub = readWavetable(sineTable, voice.subOsc.phase);
            float saw = readWavetable(sawTable, voice.osc.phase);
            sample = 0.5f * main + 0.35f * sub + 0.15f * saw;
            break;
        }
            
        case INST_PAD: {
            // Pad: Detuned oscillators for chorus effect
            float p1 = readWavetable(sineTable, voice.osc.phase);
            float p2 = readWavetable(sineTable, voice.detunedOsc[0].phase);
            float p3 = readWavetable(sineTable, voice.detunedOsc[1].phase);
            sample = (p1 + p2 + p3) * 0.33f;
            break;
        }
            
        case INST_LEAD: {
            // Lead: Pulse wave (square with harmonics) + slight detune
            float sq = readWavetable(squareTable, voice.osc.phase);
            float saw = readWavetable(sawTable, voice.detunedOsc[0].phase);
            sample = 0.7f * sq + 0.3f * saw;
            break;
        }
            
        default:
            sample = readWavetable(sineTable, voice.osc.phase);
            break;
    }
    
    // Apply amplitude envelope
    float envLevel = voice.ampEnv.process();
    
    // Check if voice should be deactivated
    if (!voice.ampEnv.isActive()) {
        voice.reset();
        return 0.0f;
    }
    
    sample *= envLevel * voice.velocity;
    
    // Advance all oscillator phases
    voice.osc.phase += voice.osc.phaseIncrement;
    if (voice.osc.phase >= 1.0) voice.osc.phase -= 1.0;
    
    voice.subOsc.phase += voice.subOsc.phaseIncrement;
    if (voice.subOsc.phase >= 1.0) voice.subOsc.phase -= 1.0;
    
    voice.detunedOsc[0].phase += voice.detunedOsc[0].phaseIncrement;
    if (voice.detunedOsc[0].phase >= 1.0) voice.detunedOsc[0].phase -= 1.0;
    
    voice.detunedOsc[1].phase += voice.detunedOsc[1].phaseIncrement;
    if (voice.detunedOsc[1].phase >= 1.0) voice.detunedOsc[1].phase -= 1.0;
    
    return sample;
}

// ============================================================================
// SOFT CLIPPING
// ============================================================================

float AudioEngine::softClip(float sample) {
    // Soft saturation curve (tanh-like but cheaper)
    if (sample > 0.9f) {
        return 0.9f + 0.1f * tanhf((sample - 0.9f) * 5.0f);
    } else if (sample < -0.9f) {
        return -0.9f + 0.1f * tanhf((sample + 0.9f) * 5.0f);
    }
    return sample;
}

// ============================================================================
// MAIN AUDIO GENERATION
// ============================================================================

void AudioEngine::generateAudioBlock(int32_t* outputBuffer, size_t frames) {
    if (!sineTable) return;  // Wavetables not ready
    
    // Process each frame
    for (size_t i = 0; i < frames; i++) {
        float mixL = 0.0f;
        float mixR = 0.0f;
        int activeCount = 0;
        
        // Take mutex briefly for voice processing
        if (xSemaphoreTake(voiceMutex, 0) == pdTRUE) {
            // Sum all active voices
            for (int v = 0; v < MAX_POLYPHONY; v++) {
                if (voices[v].active) {
                    float voiceSample = generateVoiceSample(voices[v]);
                    mixL += voiceSample;
                    mixR += voiceSample;
                    if (voices[v].active) activeCount++;
                }
            }
            xSemaphoreGive(voiceMutex);
        }
        
        // Normalize for polyphony (prevent clipping with many voices)
        if (activeCount > 1) {
            float normFactor = 1.0f / sqrtf((float)activeCount);
            mixL *= normFactor;
            mixR *= normFactor;
        }
        
        // Apply master volume (with headroom)
        mixL *= masterVolume * 0.9f;
        mixR *= masterVolume * 0.9f;
        
        // Apply master low-pass filter
        // Simple one-pole LP: y[n] = y[n-1] + alpha * (x[n] - y[n-1])
        float lpfAlpha = 0.1f + filterCutoff * 0.89f;  // Range: 0.1 to 0.99
        masterLPState[0] += lpfAlpha * (mixL - masterLPState[0]);
        masterLPState[1] += lpfAlpha * (mixR - masterLPState[1]);
        mixL = masterLPState[0];
        mixR = masterLPState[1];
        
        // DC Blocking Filter (high-pass at ~5Hz)
        // y[n] = x[n] - x[n-1] + 0.9995 * y[n-1]
        const float dcBlockCoeff = 0.9997f;
        float dcOutL = mixL - dcBlockX[0] + dcBlockCoeff * dcBlockY[0];
        float dcOutR = mixR - dcBlockX[1] + dcBlockCoeff * dcBlockY[1];
        dcBlockX[0] = mixL;
        dcBlockX[1] = mixR;
        dcBlockY[0] = dcOutL;
        dcBlockY[1] = dcOutR;
        mixL = dcOutL;
        mixR = dcOutR;
        
        // Soft clipping / limiting
        mixL = softClip(mixL);
        mixR = softClip(mixR);
        
        // Final hard limit (should rarely trigger with soft clip)
        mixL = constrain(mixL, -1.0f, 1.0f);
        mixR = constrain(mixR, -1.0f, 1.0f);
        
        // Update visualizer
        visualizerBuffer[visualizerIndex] = (mixL + mixR) * 0.5f;
        visualizerIndex = (visualizerIndex + 1) & 127;
        
        // Track peak level for visualizer
        float currentPeak = fabsf(mixL) > fabsf(mixR) ? fabsf(mixL) : fabsf(mixR);
        if (currentPeak > peakLevel) {
            peakLevel = currentPeak;
        } else {
            peakLevel *= 0.9995f;  // Slow decay
        }
        
        // Convert to 32-bit integer (24-bit audio in 32-bit container)
        // PCM5102A accepts 16/24/32-bit I2S. We'll use 32-bit for max quality
        // Left-justify 24-bit data in 32-bit word (shift by 8)
        int32_t sampleL = (int32_t)(mixL * 8388607.0f) << 8;  // 24-bit max
        int32_t sampleR = (int32_t)(mixR * 8388607.0f) << 8;
        
        // Output interleaved stereo
        outputBuffer[i * 2] = sampleL;
        outputBuffer[i * 2 + 1] = sampleR;
    }
}
