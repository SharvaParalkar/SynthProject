#ifndef AUDIO_ENGINE_H
#define AUDIO_ENGINE_H

#include <Arduino.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/semphr.h>
#include "Config.h"

// ============================================================================
// HIGH-PERFORMANCE AUDIO ENGINE FOR ESP32-S3 + PCM5102A
// ============================================================================
// Features:
// - 32-bit internal processing → 24-bit I2S output (matches PCM5102A's DAC)
// - Wavetable oscillators for efficient, alias-free synthesis
// - Proper ADSR envelopes with exponential curves
// - Oversampling for anti-aliasing
// - Dedicated audio task on Core 0
// - APLL clock for low-jitter I2S
// ============================================================================

// Audio Configuration
#define AUDIO_SAMPLE_RATE     44100
#define AUDIO_BIT_DEPTH       32          // 32-bit frames (24-bit data packed)
#define AUDIO_CHANNELS        2           // Stereo
#define AUDIO_BUFFER_FRAMES   256         // Frames per DMA buffer
#define AUDIO_DMA_BUFFERS     4           // Number of DMA buffers
#define AUDIO_OVERSAMPLING    2           // 2x oversampling for anti-aliasing

// Wavetable Configuration
#define WAVETABLE_SIZE        2048        // Power of 2 for fast indexing
#define WAVETABLE_MASK        (WAVETABLE_SIZE - 1)

// Voice Configuration  
#define MAX_POLYPHONY         8           // Maximum simultaneous voices

// ADSR Envelope States
enum EnvelopeState {
    ENV_IDLE,
    ENV_ATTACK,
    ENV_DECAY,
    ENV_SUSTAIN,
    ENV_RELEASE
};

// ADSR Parameters (in seconds)
struct ADSRParams {
    float attack  = 0.005f;   // 5ms attack
    float decay   = 0.1f;     // 100ms decay
    float sustain = 0.7f;     // 70% sustain level
    float release = 0.2f;     // 200ms release
};

// Envelope Generator
struct Envelope {
    EnvelopeState state = ENV_IDLE;
    float level = 0.0f;
    float attackRate;
    float decayRate;
    float sustainLevel;
    float releaseRate;
    
    void trigger(const ADSRParams& params);
    void release();
    void reset();
    float process();
    bool isActive() const { return state != ENV_IDLE; }
};

// Oscillator with wavetable lookup
struct Oscillator {
    double phase = 0.0;           // High-precision phase (0.0 to 1.0)
    double phaseIncrement = 0.0;  // Per-sample phase increment
    float frequency = 440.0f;
    
    void setFrequency(float freq);
    void reset() { phase = 0.0; }
};

// Voice structure
struct Voice {
    bool active = false;
    int note = -1;
    Instrument instrument = INST_SINE;
    
    Oscillator osc;
    Oscillator subOsc;           // Sub-oscillator for bass/pad sounds
    Oscillator detunedOsc[2];    // Detuned oscillators for pad/chorus
    
    Envelope ampEnv;             // Amplitude envelope
    Envelope filterEnv;          // Filter envelope (future)
    
    float velocity = 1.0f;       // Note velocity
    uint32_t startTime = 0;      // For voice stealing priority
    
    // Per-voice filter state
    float filterState = 0.0f;
    
    void noteOn(int midiNote, Instrument inst, float vel = 1.0f);
    void noteOff();
    void reset();
    float render(const float* wavetable, Instrument inst);
};

// Main Audio Engine Class
class AudioEngine {
public:
    AudioEngine();
    ~AudioEngine();
    
    // Initialization
    void init();
    void start();
    void stop();
    
    // Note Control
    void noteOn(int note, Instrument inst);
    void noteOff(int note);
    void killAll();
    
    // Voice Info
    int getActiveVoiceCount();
    
    // Volume Control (0-100)
    void setVolume(int vol);
    int getVolume();
    
    // Filter Control (0.0-1.0)
    void setFilterCutoff(float cutoff);
    float getFilterCutoff();
    
    // Visualizer
    float getVisualizerLevel();
    const float* getWaveform() { return visualizerBuffer; }
    
    // Audio Generation (called by audio task or main loop)
    void generateAudioBlock(int32_t* outputBuffer, size_t frames);
    
private:
    // Wavetables (generated at startup)
    float* sineTable;
    float* sawTable;
    float* squareTable;
    float* triangleTable;
    
    void generateWavetables();
    void destroyWavetables();
    
    // Voice management
    Voice voices[MAX_POLYPHONY];
    SemaphoreHandle_t voiceMutex;
    
    int findFreeVoice();
    int findVoiceToSteal();
    
    // Synthesis helpers
    float readWavetable(const float* table, double phase);
    float generateVoiceSample(Voice& voice);
    float midiToFrequency(int note);
    
    // Output processing
    float masterVolume = 0.8f;
    float filterCutoff = 1.0f;
    
    // Master filter state (one-pole LP)
    float masterLPState[2] = {0.0f, 0.0f};
    
    // DC Blocker state (per channel)
    float dcBlockX[2] = {0.0f, 0.0f};
    float dcBlockY[2] = {0.0f, 0.0f};
    
    // Soft clipper / limiter
    float softClip(float sample);
    
    // Visualizer buffer
    float visualizerBuffer[128];
    int visualizerIndex = 0;
    float peakLevel = 0.0f;
    
    // Audio task (optional - for dedicated core rendering)
    TaskHandle_t audioTaskHandle = nullptr;
    volatile bool audioTaskRunning = false;
    
    // ADSR presets per instrument
    ADSRParams getADSRForInstrument(Instrument inst);
};

#endif
