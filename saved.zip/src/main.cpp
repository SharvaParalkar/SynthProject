#include <Arduino.h>
#include "Config.h"
#include "Hardware.h"
#include "AudioEngine.h"
#include "Sequencer.h"
#include "UI.h"

// Modules
Hardware hardware;
AudioEngine audioEngine;
Sequencer sequencer(audioEngine);
SynthUI ui(sequencer, audioEngine, hardware);

// Application State
Mode currentMode = MODE_LAUNCHPAD;

// Audio buffers (32-bit for high-quality PCM5102A output)
int32_t audioBuffer[I2S_BUFFER_SIZE * 2]; // Stereo (L, R interleaved)

void handleInput() {
    hardware.scanButtons();
    
    // Mode Switching
    if (hardware.isModeJustPressed()) {
        currentMode = (Mode)((currentMode + 1) % 4); // 4 modes now
        audioEngine.killAll();
        // Force Display Update
        ui.draw(currentMode); // Immediate feedback (Issue #21/23)
        return;
    }
    
    // Octave / Function
    if (hardware.isOctaveJustPressed()) {
        if (currentMode == MODE_LAUNCHPAD) {
            int oct = sequencer.getCurrentOctave();
            oct = (oct + 1) % 7;
            if (oct == 0) oct = 2;
            sequencer.setCurrentOctave(oct);
        } else if (currentMode == MODE_SEQUENCER) {
            int trk = sequencer.getCurrentTrack();
            sequencer.setCurrentTrack((trk + 1) % 4);
        }
    }
    
    // Matrix Handling
    for (int r = 0; r < 4; r++) {
        for (int c = 0; c < 4; c++) {
            // Check for Press
            if (hardware.isPadJustPressed(r, c)) {
                int padIndex = r * 4 + c;
                
                if (currentMode == MODE_LAUNCHPAD) {
                    // Play Note
                    int note = 36 + padIndex + (sequencer.getCurrentOctave() * 12);
                    Instrument inst = sequencer.getInstrument(sequencer.getCurrentTrack());
                    audioEngine.noteOn(note, inst);
                    
                } else if (currentMode == MODE_SEQUENCER) {
                    // Toggle Step
                    sequencer.toggleStep(sequencer.getCurrentTrack(), padIndex);
                    
                } else if (currentMode == MODE_SETTINGS) {
                    // Menu Navigation
                    // 0: Up, 1: Down, 2: Select
                    if (padIndex == 0) {
                        ui.menuCursor--;
                        if (ui.menuCursor < 0) {
                            ui.menuCursor = MENU_ITEM_COUNT - 1;
                            ui.menuScroll = max(0, ui.menuCursor - 3);
                        } else if (ui.menuCursor < ui.menuScroll) {
                            ui.menuScroll = ui.menuCursor;
                        }
                    } else if (padIndex == 1) { 
                        ui.menuCursor++;
                        if (ui.menuCursor >= MENU_ITEM_COUNT) {
                            ui.menuCursor = 0;
                            ui.menuScroll = 0;
                        } else if (ui.menuCursor >= ui.menuScroll + 4) {
                            ui.menuScroll = ui.menuCursor - 3;
                        }
                    } else if (padIndex == 2) { 
                        // Select / Action
                        int item = ui.menuCursor;
                        if (item == MENU_INSTRUMENT) {
                            int trk = sequencer.getCurrentTrack();
                            Instrument inst = sequencer.getInstrument(trk);
                            inst = (Instrument)((inst + 1) % INST_COUNT);
                            sequencer.setInstrument(trk, inst);
                        } else if (item == MENU_BPM) {
                             int b = sequencer.getBPM();
                             b += 20; if (b > 180) b = 60;
                             sequencer.setBPM(b);
                        } else if (item == MENU_PLAY_PAUSE) {
                             sequencer.togglePlay();
                        } else if (item == MENU_CLEAR_TRACK) {
                             sequencer.clearTrack(sequencer.getCurrentTrack());
                             ui.menuCursor = 0;
                             ui.menuScroll = 0;
                        } else if (item == MENU_VOLUME) {
                             // Cycle + 20
                             int v = audioEngine.getVolume() + 20;
                             if (v > 100) v = 0;
                             audioEngine.setVolume(v);
                         } else if (item == MENU_BRIGHTNESS) {
                             // Cycle + 50ish (20%)
                             int b = hardware.getBrightness();
                             b += 51; // 20% of 255
                             if (b > 255) b = 0;
                             hardware.setBrightness(b);
                         }
                    } 
                    
                    // Fine Adjustments (Pad 3: -, Pad 4: +)
                    if (padIndex == 3) { // Decrease
                        if (ui.menuCursor == MENU_BPM) sequencer.setBPM(max(60, sequencer.getBPM() - 5));
                        else if (ui.menuCursor == MENU_VOLUME) audioEngine.setVolume(audioEngine.getVolume() - 5);
                        else if (ui.menuCursor == MENU_BRIGHTNESS) hardware.setBrightness(hardware.getBrightness() - 13); // ~5%
                    } else if (padIndex == 4) { // Increase
                        if (ui.menuCursor == MENU_BPM) sequencer.setBPM(min(180, sequencer.getBPM() + 5));
                        else if (ui.menuCursor == MENU_VOLUME) audioEngine.setVolume(audioEngine.getVolume() + 5);
                        else if (ui.menuCursor == MENU_BRIGHTNESS) hardware.setBrightness(hardware.getBrightness() + 13);
                    }
                    
                } else if (currentMode == MODE_NOTE_EDITOR) {
                    // Note Editor Menu Navigation
                    // 0: Up, 1: Down, 2: Select
                    if (padIndex == 0) {
                        ui.noteMenuCursor--;
                        if (ui.noteMenuCursor < 0) {
                            ui.noteMenuCursor = NOTE_MENU_ITEM_COUNT - 1;
                            ui.noteMenuScroll = max(0, ui.noteMenuCursor - 3);
                        } else if (ui.noteMenuCursor < ui.noteMenuScroll) {
                            ui.noteMenuScroll = ui.noteMenuCursor;
                        }
                    } else if (padIndex == 1) { 
                        ui.noteMenuCursor++;
                        if (ui.noteMenuCursor >= NOTE_MENU_ITEM_COUNT) {
                            ui.noteMenuCursor = 0;
                            ui.noteMenuScroll = 0;
                        } else if (ui.noteMenuCursor >= ui.noteMenuScroll + 4) {
                            ui.noteMenuScroll = ui.noteMenuCursor - 3;
                        }
                    } else if (padIndex == 2) { 
                        // Select / Action
                        int item = ui.noteMenuCursor;
                        if (item == NOTE_MENU_SWING) {
                            // Cycle through preset values: 0, 25, 50, 75, 100
                            int s = sequencer.getSwing();
                            if (s == 0) s = 25;
                            else if (s == 25) s = 50;
                            else if (s == 50) s = 75;
                            else if (s == 75) s = 100;
                            else s = 0;
                            sequencer.setSwing(s);
                        } else if (item == NOTE_MENU_GATE) {
                            // Cycle through preset values: 0.25, 0.5, 0.75, 1.0
                            float g = sequencer.getGate();
                            if (g < 0.3f) g = 0.5f;
                            else if (g < 0.6f) g = 0.75f;
                            else if (g < 0.9f) g = 1.0f;
                            else g = 0.25f;
                            sequencer.setGate(g);
                        } else if (item == NOTE_MENU_FILTER) {
                            // Cycle through preset values: 0.25, 0.5, 0.75, 1.0
                            float f = audioEngine.getFilterCutoff();
                            if (f < 0.3f) f = 0.5f;
                            else if (f < 0.6f) f = 0.75f;
                            else if (f < 0.9f) f = 1.0f;
                            else f = 0.25f;
                            audioEngine.setFilterCutoff(f);
                        }
                    }
                    
                    // Fine Adjustments (Pad 3: -, Pad 4: +)
                    if (padIndex == 3) { // Decrease
                        if (ui.noteMenuCursor == NOTE_MENU_SWING) sequencer.setSwing(max(0, sequencer.getSwing() - 5));
                        else if (ui.noteMenuCursor == NOTE_MENU_GATE) sequencer.setGate(max(0.0f, sequencer.getGate() - 0.05f));
                        else if (ui.noteMenuCursor == NOTE_MENU_FILTER) audioEngine.setFilterCutoff(max(0.0f, audioEngine.getFilterCutoff() - 0.05f));
                    } else if (padIndex == 4) { // Increase
                        if (ui.noteMenuCursor == NOTE_MENU_SWING) sequencer.setSwing(min(100, sequencer.getSwing() + 5));
                        else if (ui.noteMenuCursor == NOTE_MENU_GATE) sequencer.setGate(min(1.0f, sequencer.getGate() + 0.05f));
                        else if (ui.noteMenuCursor == NOTE_MENU_FILTER) audioEngine.setFilterCutoff(min(1.0f, audioEngine.getFilterCutoff() + 0.05f));
                    }
                }
            } // End Press Check

            // Check for Release
            if (hardware.isPadJustReleased(r, c)) {
                if (currentMode == MODE_LAUNCHPAD) {
                    int padIndex = r * 4 + c;
                    int note = 36 + padIndex + (sequencer.getCurrentOctave() * 12);
                    audioEngine.noteOff(note); // Stop note
                }
            }
        }
    }
}

void setup() {
    Serial.begin(115200);
    delay(500);
    Serial.println("Booting Modular Synth...");
    
    // Init Modules
    hardware.init();
    ui.init();
    audioEngine.init();
    sequencer.init();
    
    ui.draw(currentMode);
}

void loop() {
    // 1. Audio Generation (Highest Priority)
    // Generate I2S_BUFFER_SIZE stereo frames into 32-bit buffer
    // The new engine uses wavetable synthesis with band-limited oscillators
    
    memset(audioBuffer, 0, sizeof(audioBuffer));
    
    // Generate audio block (32-bit samples, interleaved stereo)
    audioEngine.generateAudioBlock(audioBuffer, I2S_BUFFER_SIZE);
    
    // 2. Output to I2S/PCM5102A
    // Size in bytes: frames * 2 channels * 4 bytes per sample (32-bit)
    hardware.writeAudio(audioBuffer, I2S_BUFFER_SIZE * 2 * sizeof(int32_t));
    
    // 3. Inputs (Throttled)
    static int inputDiv = 0;
    if (++inputDiv >= 4) { // Every ~25ms
        handleInput();
        inputDiv = 0;
    }
    
    // 4. Logic
    sequencer.update();
    
    // 5. LEDs
    static int ledDiv = 0;
    if (++ledDiv >= 8) {
        if (currentMode == MODE_SEQUENCER && sequencer.isPlayingState()) {
            hardware.setStepLEDs(sequencer.getCurrentStep());
        } else {
            hardware.setGroupLEDs(sequencer.getCurrentTrack());
        }
        ledDiv = 0;
    }
    
    // 6. Display (Low Priority)
    static int dispDiv = 0;
    if (++dispDiv >= 6) { // Every ~24ms (Assuming 4ms audio buffer loop)
        ui.draw(currentMode);
        dispDiv = 0;
    }
}
